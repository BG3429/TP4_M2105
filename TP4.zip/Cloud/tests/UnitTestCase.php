<?php
class UnitTestCase extends PHPUnit_Framework_TestCase{
	
}