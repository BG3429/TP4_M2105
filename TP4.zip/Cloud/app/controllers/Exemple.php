<?php
use micro\orm\DAO;
class Exemple extends BaseController //héritage de la classe Controleur
{

	public function index()
	{

		$services = DAO::getAll("Service");
		//var_dump($services);

		foreach ($services as $service)
		{
			echo $service->getNom().'<br>';
		}

	}

	public function users()
	{

		$users = DAO::getAll("Utilisateur");
		//var_dump($Utilisateur);

		$this->loadView("Exemple/users",["users"=>$users]);

	}
	
	public function disques($idUSer){										# mettre /1 ou /2 à la fin de l'url
		$disques=DAO::getAll("Disque","idUtilisateur=".$idUSer);
		$this->loadView("Exemple/disque.html",["disks"=>$disques]);	
	}
	public function userDisques(){
		$users = DAO::getAll("Utilisateur");
		foreach ($users as $user){
			$disques=DAO::getOneToMany($user, "disques");
			if(sizeof($disques)>0)
				$this->loadView("Exemple/userDisques.html",["user"=>$user,"disques"=>$disques]);
		}
		
	}
	
	public function serviceAdd($nom,$prix=0){
		$service= new Service();
		$service->setNom($nom);
		$service->setPrix($prix);
		if(DAO::insert($service)){
			echo "Le service {$service} a été ajouté.";	
		}else{
			echo "Impossible d'ajouter le service.";
		}
	}
	
	public function userAdd($nom,$prix=0){
		$user= new Utilisateur();
		$user->setLogin($login);
		
	}

}