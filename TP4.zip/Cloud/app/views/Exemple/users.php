<div class="container">
	<ul>
	<?php
	foreach ($users as $user)
	{
		echo "<li>{$user->getLogin()}<a href='Exemple/disques/{$user->getId()}'><b> (Disques)</b></a></li>";
	}
	?>
	</ul>
</div>