<?php

/**
 * Annotation Transient
 * @author jc
 * @version 1.0.0.2
 * @package annotations
 * @Target("property")
 */
class Transient extends \Annotation{

}