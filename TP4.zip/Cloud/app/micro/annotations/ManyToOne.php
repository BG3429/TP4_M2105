<?php

/**
 * Annotation ManyToOne
 * @author jc
 * @version 1.0.0.2
 * @package annotations
 * @Target("property")
 */
class ManyToOne extends \Annotation{

}