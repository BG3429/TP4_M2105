<?php
/**
 * Annotation Id
 * @author jc
 * @version 1.0.0.1
 * @package annotations
 * @Target("property")
 */
class Id extends \Annotation{

}