# Cloud
[![Build Status](https://travis-ci.org/jcheron/Cloud.svg?branch=master)](https://travis-ci.org/jcheron/Cloud)
[![codecov](https://codecov.io/gh/jcheron/Cloud/branch/master/graph/badge.svg)](https://codecov.io/gh/jcheron/Cloud)

sept-oct 2016 project
# Howto

- [x] fork your own copy of this repository.
- [x] Clone the project on your local machine.
- [x] read the project specifications : [Cloud specifications](http://slamwi.kobject.net/slam4/cloud).
- [x] do some regular commits and pushs 
